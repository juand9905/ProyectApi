package com.df.api;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

import com.df.api.ApiManager.RetrofitClient;
import com.df.api.models.Ability;
import com.df.api.models.Civilization;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AbilityDetail extends AppCompatActivity {

    private String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ability_detail);
        Bundle in = getIntent().getExtras();
        id = in.getString("id");
        getAbilityById(id);
    }

    private void getAbilityById(String id ){
        Call<Ability> call = RetrofitClient.getInstance().getMyApi().getAbility(id);
        call.enqueue(new Callback<Ability>() {
            @Override
            public void onResponse(Call<Ability> call, Response<Ability> response) {
                Ability myAbility = response.body();
                Toast.makeText(getApplicationContext(), myAbility.getNameAbility(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<Ability> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Ocurrio un error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}