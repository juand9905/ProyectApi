package com.df.api.models;

import com.google.gson.annotations.SerializedName;

public class Ability {

    @SerializedName("id")
    private String idAbility;

    @SerializedName("name")
    private  String nameAbility;

    public String getIdAbility() {
        return idAbility;
    }

    public String getNameAbility() { return nameAbility;
    }

    public void setIdAbility(String idAbility) {
        this.idAbility = idAbility;
    }

    public void setNameAbility(String nameAbility) {
        this.nameAbility = nameAbility;
    }

}
